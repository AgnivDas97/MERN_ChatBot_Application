const chats =[
    {
        isGroupChat:false,
        users:[
            {
                name:"jhon name",
                email:"agniv@example.com"
            },
            {
                name:"jhon name",
                email:"agniv@example.com"
            }
        ],
            _id:12345678,
            chatName:"agniv"
    },
    {
        isGroupChat:false,
        users:[
            {
                name:"kckhsdck name",
                email:"agniv@example.com"
            },
            {
                name:"jhon name",
                email:"agniv@example.com"
            }
        ],
            _id:123456789,
            chatName:"agniv"
    }
]

module.exports=chats;